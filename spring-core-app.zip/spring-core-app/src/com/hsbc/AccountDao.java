package com.hsbc;

import java.util.List;

public interface AccountDao {

	public void createAccount();
	public List<String> getAccounts();
}
